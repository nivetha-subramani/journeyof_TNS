package com.springsample.spring_bootsample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootsampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
